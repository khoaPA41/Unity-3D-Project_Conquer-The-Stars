using System;
using UnityEngine;

namespace ConquerTheStars.InputController
{
    public class PlayerInputReader : MonoBehaviour, PlayerInput.IPlayerActions
    {
        public Vector2 Movement { get; set; }
        public bool Interact { get; set; }
        public bool Attack { get; set; }
        public event Action SettingUiAction = delegate { };

        private PlayerInput _playerInput;

        private void Awake()
        {
            _playerInput = new PlayerInput();
            _playerInput.Player.SetCallbacks(this);
            Cursor.lockState = CursorLockMode.Locked;
        }

        private void OnEnable() => _playerInput.Enable();

        private void OnDisable() => _playerInput.Disable();

        public void OnMove(UnityEngine.InputSystem.InputAction.CallbackContext context)
        {
            Movement = context.ReadValue<Vector2>();
        }

        public void OnAttack(UnityEngine.InputSystem.InputAction.CallbackContext context)
        {
            if (context.performed || context.canceled)
            {
                Attack = false;
                return;
            }
            Attack = true;
        }

        public void OnInteract(UnityEngine.InputSystem.InputAction.CallbackContext context)
        {
            if (context.performed || context.canceled)
            {
                Interact = false;
                return;
            }
            Interact = true;
        }

        public void OnLook(UnityEngine.InputSystem.InputAction.CallbackContext context)
        {

        }

        public void OnTab(UnityEngine.InputSystem.InputAction.CallbackContext context)
        {
            if (context.started)
            {
                SettingUiAction?.Invoke();
            }
        }
    }

}