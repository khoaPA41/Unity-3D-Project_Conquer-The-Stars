using System.Collections;
using ConquerTheStars.Pattern.StateMachine.PlayerCombat;
using ConquerTheStars.Stats;
using UnityEngine;

namespace ConquerTheStars.Pattern.StateMachine.Battle
{
    public class EnemyExecutionState : BattleBaseState
    {
        public EnemyExecutionState(BattleStateMachine battleStateMachine) : base(battleStateMachine)
        {
        }

        public override void Enter()
        {
            battleStateMachine.EnemyStateMachine.HighlightCurrentTurn.InactiveHighlight();

            // battleStateMachine.InputReader.EnterTargetAction += PlayerDodge;
            // battleStateMachine.InputReader.BlockAction += PlayerBlock;

            battleStateMachine.TouchSwipeController.DodgeAction += PlayerDodge;
            battleStateMachine.TouchSwipeController.ParryAction += PlayerBlock;

            battleStateMachine.EnemyStateMachine.IsFinished = false;

            battleStateMachine.StartCoroutine(WaitToEndAttack());
        }

        public override void Tick(float deltaTime)
        {
        }

        public override void Exit()
        {
            // battleStateMachine.InputReader.EnterTargetAction -= PlayerDodge;
            // battleStateMachine.InputReader.BlockAction -= PlayerBlock;
            battleStateMachine.TouchSwipeController.DodgeAction -= PlayerDodge;
            battleStateMachine.TouchSwipeController.ParryAction -= PlayerBlock;
        }

        private IEnumerator WaitToEndAttack()
        {
            //Prepare attack
            SwitchAttackByType();

            // Listen event for exact the frame attack deals damage
            battleStateMachine.EnemyStateMachine.AttackDealDamage += EnemyDealDamage;

            //Wait until player attack animation done
            yield return new WaitUntil(() => battleStateMachine.EnemyStateMachine.IsFinished == true);

            // Clear event to avoid double call / memory leak
            battleStateMachine.EnemyStateMachine.AttackDealDamage -= EnemyDealDamage;
            battleStateMachine.SwitchResolve();
        }

        private void EnemyDealDamage()
        {
            var target = battleStateMachine.EnemyTargeter.CurrentTarget.GetComponent<PlayerCombatStateMachine>();
            var playerStatsManager = battleStateMachine.EnemyTargeter.CurrentTarget.GetComponent<CharacterStatsManagers>();
            if (target == null) return;

            //  Calculate damage if critical
            var isCrit = battleStateMachine.EnemyStateMachine.CharacterStatsManagers.RandomCritical();
            var damage = isCrit ?
                        battleStateMachine.EnemyStateMachine.CharacterStatsManagers.CalculateCriticalDamage() :
                        battleStateMachine.EnemyStateMachine.CharacterStatsManagers.CurrentAttackDamage;


            // TakeDamage will return false if player block / dodge
            if (playerStatsManager.TakeDamage(damage, isCrit, battleStateMachine.CurrentTurn.HitVFXName))
            {
                // Play hit sound if player take dmg
                battleStateMachine.EnemyStateMachine.PlayHitSound();

                target.SwitchState(target.PlayerGetHitState);

                // Track battle statistics for result screen
                target.BattleStatistics.DamageReceived += damage;
                Debug.Log($"DAMGE RECEIVER: {damage}");

            }
            else
            {
                // Track battle statistics for result screen
                if (playerStatsManager.IsDodge)
                {
                    // Play dodge sound if player dodge succes
                    target.PlayDodgeSound();

                    target.BattleStatistics.SuccessfulDodgeTimes++;
                }

                if (playerStatsManager.IsBlock)
                {
                    // Play parry sound if player dodge succes
                    target.PlayParrySound();

                    target.BattleStatistics.SuccessfulParryTimes++;
                }
            }
        }

        private void PlayerDodge()
        {
            battleStateMachine.EnemyTargeter.CurrentTarget.GetComponent<PlayerCombatStateMachine>().SwitchDodgeState();
        }

        private void PlayerBlock()
        {
            battleStateMachine.EnemyTargeter.CurrentTarget.GetComponent<PlayerCombatStateMachine>().SwitchBlockState();
        }

        private void SwitchAttackByType()
        {
            if (battleStateMachine.EnemyStateMachine.IsBoss)
            {
                battleStateMachine.EnemyStateMachine.SwitchBossAttackState();
                return;
            }
            battleStateMachine.EnemyStateMachine.SwitchAttackState();

        }
    }
}
